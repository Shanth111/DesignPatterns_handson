package com.cognizant.designPatterns;

public interface IRepair {
	
}